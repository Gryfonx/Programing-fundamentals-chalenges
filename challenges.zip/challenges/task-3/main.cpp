#include <iostream>
#include <string>
#include <cmath>


const int ERROR_STRING_INPUT = 1;

using namespace std;
int main()
{
    string input;
    bool num_check;
    cout << "Please enter any number \n";
    cin >> input;
    for (int i = 0; i < input.length(); i++)
    {

        if (!isdigit(input[i]))
        {
            num_check = false;
        }

        else
        {

            num_check = true;
        }
    }

    if (num_check == false)
    {
        cerr << "[!] You have entered a string not a valid number";
        return ERROR_STRING_INPUT;

    }

    else
    {
        double x = stod(input);
        double negatedx = (x * (-1));
        int absoloutex = abs(x);
        double squaredx = pow(x, 2);
        double cubedx = pow(x, 3);
        double rootx = sqrt(x);
        double floorx = floor(x);
        double ceilingx = ceil(x);
        double roundedx = round(x);

        cout << "neg(x): " << negatedx << "\n";
        cout << "abs(x): " << absoloutex << "\n";
        cout << "pow2(x): " << squaredx << "\n";
        cout << "pow3(x): " << cubedx << "\n";
        cout << "sqrt(x): " << rootx << "\n";
        cout << "floor(x): " << floorx << "\n";
        cout << "ceil(x): " << ceilingx << "\n";
        cout << "round(x): " << roundedx << "\n";
    }
}