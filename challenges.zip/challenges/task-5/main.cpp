#include <iostream>
#include <string>
#include <cctype>


const int ERROR_STRING_INPUT = 1;


using namespace std;
void sentenceCase(string input)
{
    string sentencecase;
    bool newsentence = true;

    for (int i = 0; i < input.size(); i++)
    {
        if (newsentence == true)
        {
            sentencecase += toupper(input[i]);
            if (input[i] != ' ')
            {
                newsentence = false;
            }
        }

        else if (newsentence == false)
        {
            sentencecase += tolower(input[i]);

        }

        if (input[i] == '.' || input[i] == '?' || input[i] == '!')
        {
            newsentence = true;
        }
    }
    cout << "Sentence case --->   " << sentencecase << "\n";
}

void alternatingCase(string input)
{
    string alternatingcase;
    bool alternate = 1;
    for (int i = 0; i < input.size(); i++)
    {
        if (alternate == 1)
        {
            alternatingcase += toupper(input[i]);
            if (input[i] != '.' || input[i] != '?' || input[i] != '!' || input[i] != ' ')
            {
                alternate = 0;
            }

        }

        else if (alternate == 0)
        {
            alternatingcase += tolower(input[i]);
            if (input[i] != '.' || input[i] != '?' || input[i] != '!' || input[i] != ' ')
            {
                alternate = 1;
            }
        }
    }
    cout << "Alternate case --->   " << alternatingcase << "\n";
}

void upperCase(string input)
{
    string uppercase;
    for (int i = 0; i < input.size(); i++)
    {
        uppercase += toupper(input[i]);
    }
    cout << "Uppercase --->   " << uppercase << "\n";
}

void lowerCase(string input)
{
    string lowercase;
    for (int i = 0; i < input.size(); i++)
    {
        lowercase += tolower(input[i]);
    }
    cout << "Lowercase --->   " << lowercase << "\n";
}
int main()
{
    string input;
    bool char_check;
    cout << "Enter String:" << "\n";
    getline(cin, input);
    for (int i = 0; i < input.length(); i++)
    {

        if (!isdigit(input[i]))
        {
            char_check = true;
        }

        else
        {

            char_check = false;
        }
    }

    if (char_check == false)
    {
        cerr << "[!] Your string contains your number";
        return ERROR_STRING_INPUT;
    }

    else
    {
        upperCase(input);
        lowerCase(input);
        alternatingCase(input);
        sentenceCase(input);
    }

}