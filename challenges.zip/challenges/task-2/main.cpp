#include <iostream>
#include <string>


using namespace std;
int main()
{
    string name;
    string username;
    string clan;
    string written_exp;
    string exp;
    bool checkloop = true;
    bool int_check;
    int level;
    int remainder;

    cout << "What is your name?  ";
    cin >> name;
    cout << "\n What is your username?  ";
    cin >> username;
    cout << "\n What clan are you in?  ";
    cin >> clan;
    cout << "\n How much exp do you have?  ";
    while (checkloop)
    {
        cin >> exp;
        for (int i = 0; i < exp.length(); i++)
        {

            if (!isdigit(exp[i]))
            {
                int_check = true;
            }

            else
            {

                int_check = false;
            }
        }

        if (int_check == true)
        {
            cout << "\n Please enter a number  ";
        }

        else
        {
            checkloop = false;
        }

    }

    int xp = stoi(exp);
    int r = xp % 100;
    remainder = 100 - r;
    level = xp / 100;
    cout << "\n Your name is " << name << " and your in-game name is [" << clan << "] " << username;
    cout << "\n your level is " << level << " and you need " << remainder << " exp to level up again";
}