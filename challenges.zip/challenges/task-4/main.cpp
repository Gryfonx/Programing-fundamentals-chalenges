#include <iostream>
#include <string>
#include <cctype>





using namespace std;

bool containsSpecialChar(char inputChar)
{
    if (ispunct(inputChar))
    {
        return true;
    }

    else
    {
        return false;
    }
}

bool containsNum(char inputChar)
{
    if (isdigit(inputChar))
    {
        return true;
    }

    else
    {
        return false;
    }
}

void ascii(string input)
{
    for (int i = 0; i < input.length(); i++)
    {
        cout << "+=-=-=";
    }
    cout << "+\n";
    for (int i = 0; i < input.length(); i++)
    {
        cout << "|  " << input.at(i) << "  ";
    }
    cout << "|\n";
    for (int i = 0; i < input.length(); i++)
    {
        cout << "+=-=-=";
    }
    cout << "+\n";
}

int main()
{
    cout << "Enter a string please \n";
    string input;
    bool loop = true;

    while (loop)
    {
        bool check_loop = true;
        bool exit_check = true;

        while (check_loop)
        {
            cin >> input;

            for (int i = 0; i < input.size(); i++)
            {
                if (containsSpecialChar(input[i]) && !containsNum(input[i]))
                {
                    cerr << "ERROR: String contains a special character! \n";
                    break;
                }

                else if (containsNum(input[i]) && !containsSpecialChar(input[i]))
                {
                    cerr << "ERROR: String contains a number! \n";
                    break;
                }

                else if (containsNum(input[i]) && containsSpecialChar(input[i]))
                {
                    cerr << "ERROR: String contains a number and special character! \n";
                    break;
                }

            }
            if (input.empty())
            {
                cerr << "ERROR: The string is empty! \n";
                break;
            }

            else
            {
                check_loop = false;
            }


            if (check_loop == true)
            {
                cout << "please enter a valid string";
            }


        }
        ascii(input);
        cout << "\n Please enter another string \n";
    }
}