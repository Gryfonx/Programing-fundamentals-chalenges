#include "main.h"
#include <iostream>
#include <string>
using namespace std;
bool guessLoop = true;
int guessCount = 0;
int guess;

void comparison(int mysteryNumber, int guess)
{

    int difference = guess - mysteryNumber;
    difference = abs(difference);

    if (difference >= 50)
    {
        cout << "freezing \n";
    }

    else if (35 <= difference && 50 > difference)
    {
        cout << "colder \n";
    }

    else if (25 <= difference && 35 > difference)
    {
        cout << "cold \n";
    }

    else if (15 <= difference && 25 > difference)
    {
        cout << "warm \n";
    }

    else if (10 <= difference && 15 > difference)
    {
        cout << "warmer \n";
    }

    else if (5 <= difference && 10 > difference)
    {
        cout << "hot \n";
    }

    else if (3 <= difference && 5 > difference)
    {
        cout << "hotter \n";
    }

    else if (1 <= difference && 2 >= difference)
    {
        cout << "boiling \n";
    }

    else if (difference == 0)
    {
        guessLoop = false;
    }
}

int main(int argc, char* argv[])
{
    bool checkloop = true;
    bool int_check;
    int mysteryNumber = random(1, 100);
    mysteryNumber = abs(mysteryNumber);
    string guesstext;



    while (guessLoop)
    {
        cout << "Guess the number- it's between 1 and 100 \n";
        cin >> guesstext;

        while (checkloop)
        {

            for (int i = 0; i < guesstext.length(); i++)
            {

                if (!isdigit(guesstext[i]))
                {
                    int_check = true;
                }

                else
                {

                    int_check = false;
                }
            }

            if (int_check == true)
            {
                cerr << "[!] Letters Detected, Enter a number";
            }

            else
            {
                guess = stoi(guesstext);

                if (1 > guess && 100 > guess)
                {
                    cerr << "[!] Out of range, Enter a number between 1 and 100";
                }
                checkloop = false;
            }

        }

        guess = abs(guess);

        guessCount++;
        comparison(mysteryNumber, guess);
    }
    cout << "\nHooray! You found the Missing number in " << guessCount << " guesses!";
}